package com.example.bis;

import java.util.ArrayList;

public class NarucivanjePretragaDataStorage {

    public static ArrayList<String> listViewData = new ArrayList<String>();

    public static void fillData() {

        {
            listViewData.add("                  Dijagnostika kože i tkiva");
            listViewData.add("                  Dijagnostika gornjih\n                  dišnih putova");
            listViewData.add("                  Hemokultura");
            listViewData.add("                  Koprokultura");
            listViewData.add("                  Molekularna dijagnostika");
            listViewData.add("                  Mikologija");
            listViewData.add("                  Nadzorne kulture");
            listViewData.add("                  Parazitologija");
            listViewData.add("                  Serologija");
            listViewData.add("                  Urogenitalna dijagnostika");
            listViewData.add("                  TBC");
        }
    }
}
